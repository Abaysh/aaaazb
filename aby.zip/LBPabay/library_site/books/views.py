from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, FormView, UpdateView

from .models import Book
from .forms import BookForm


class BookListView(ListView):

    model = Book
    queryset = Book.objects.all()


class BookDetailView(UpdateView, DetailView):

    model = Book
    form_class = BookForm
    success_url = '/books/'
    template_name = 'books/book_detail.html'

    def get_success_url(self):
        pk = self.kwargs.get('pk')
        return reverse_lazy('book-detail', kwargs={'pk': pk})

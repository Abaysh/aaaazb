# library_site

# Запуск
```
git clone https://github.com/ema5353/library_site
```
```
cd library_site
```
``` 
virtualenv venv 
```
``` 
source venv/bin/activate 
```

``` 
pip install -r requirements.txt
```

``` 
python3 manage.py migrate
```
``` 
python3 manage.py createsuperuser
```
``` 
python3 manage.py runserver 
```
